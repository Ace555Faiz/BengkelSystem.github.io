<footer>
    <style type="text/css">
    
    body {
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    main {
        flex: 1;
    }

    footer {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        background-color: rgba(76, 175, 80, 0.7); /* Using rgba() with alpha value 0.7 for transparency */
        text-align: center;
        padding: 5px;
    }

    footer p {
        margin: 0;
    }
    </style>
    <!-- Footer content, such as copyright information and links -->
    <strong><p>&copy; <?php echo date('Y'); ?> E-Foremen System. All rights reserved.</p><strong>
</footer>
</body>
</html>